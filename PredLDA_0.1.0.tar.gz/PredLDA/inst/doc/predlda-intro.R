## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 6,
  fig.height = 4
)

## -----------------------------------------------------------------------------
library(PredLDA)

## -----------------------------------------------------------------------------
model <- LDA$new()
model$fit(iris[, 1:4], iris$Species)
model

## -----------------------------------------------------------------------------
round(model$coefficients, 3)

## -----------------------------------------------------------------------------
round(model$means, 3)
model$priors

## -----------------------------------------------------------------------------
new_obs <- iris[c(1, 51, 101), 1:4]
model$predict(new_obs)
round(model$predict_proba(new_obs), 4)
model$score(iris[, 1:4], iris$Species)

## -----------------------------------------------------------------------------
extdir <- system.file("extdata", package = "PredLDA")
list.files(extdir)

train <- read.delim(file.path(extdir, "iris_apprentissage.tsv"),
                    check.names = FALSE)
newdata <- read.delim(file.path(extdir, "iris_nouveaux.tsv"),
                      check.names = FALSE)

xcols <- c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width")
m <- LDA$new()$fit(train[, xcols], train$Species)
data.frame(
  predicted = as.character(m$predict(newdata)),
  round(m$predict_proba(newdata[, xcols]), 4),
  Identifiant = newdata$Identifiant
)

## -----------------------------------------------------------------------------
invisible(model$summary())

